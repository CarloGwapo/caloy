# crud-vue-3

## Note
This repository is a repository of a simple frontend crud project with a vue 3 composition api. The backend repository is https://github.com/fuatakbar/backend-laravue-crud-simple
Tutorial or Source Credit from https://santrikoding.com/installasi-persiapan-laravel-8 big thanks!

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Lints and fixes files
```
npm run lint
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
